Simpan screenshot aplikasi yang benar-benar sudah dijalankan di folder ini. Nama yang disarankan: 01-login.png, 02-dashboard.png, 03-daftar-produk.png, 04-tambah-produk.png, 05-edit-produk.png.
