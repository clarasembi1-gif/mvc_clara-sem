# mY Store — UTS Praktik Pemrograman Web 2

Aplikasi manajemen produk berbasis PHP native (pola MVC) dan MySQL.

## Fitur
- Login dan logout administrator menggunakan PHP Session.
- Dashboard dengan ringkasan produk dan stok dari database.
- Daftar dan pencarian produk.
- Create, Read, Update, Delete (CRUD) produk.
- Status produk Active dan Discontinued.
- Database berisi 25 produk dummy.

## Teknologi
PHP 8+, MySQL/MariaDB, PDO, HTML, CSS.

## Instalasi XAMPP
1. Ekstrak folder `pm4_pw2_kaa_clara` ke `C:/xampp/htdocs/`.
2. Jalankan Apache dan MySQL dari XAMPP Control Panel.
3. Buka `http://localhost/phpmyadmin`, pilih Import, lalu import `mvc_mystore.sql`. SQL akan membuat database `mvc_mystore`.
4. Periksa konfigurasi koneksi di `config/database.php` (default XAMPP: user `root`, password kosong).
5. Buka `http://localhost/pm4_pw2_kaa_clara/public/`.

## Akun demo administrator
- Username: `admin`
- Password: `admin12345`

Ganti password demo sebelum aplikasi digunakan di lingkungan produksi.
