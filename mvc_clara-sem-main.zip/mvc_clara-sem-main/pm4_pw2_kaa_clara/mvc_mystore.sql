CREATE DATABASE IF NOT EXISTS mvc_mystore CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE mvc_mystore;
SET FOREIGN_KEY_CHECKS=0; DROP TABLE IF EXISTS products; DROP TABLE IF EXISTS categories; DROP TABLE IF EXISTS users; SET FOREIGN_KEY_CHECKS=1;
CREATE TABLE users(id INT AUTO_INCREMENT PRIMARY KEY,nama VARCHAR(100) NOT NULL,username VARCHAR(100) NOT NULL UNIQUE,password VARCHAR(255) NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB;
CREATE TABLE categories(id INT AUTO_INCREMENT PRIMARY KEY,nama_kategori VARCHAR(100) NOT NULL UNIQUE,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB;
CREATE TABLE products(id INT AUTO_INCREMENT PRIMARY KEY,nama_produk VARCHAR(100) NOT NULL,deskripsi TEXT NULL,harga DECIMAL(12,2) NOT NULL DEFAULT 0,stok INT NOT NULL DEFAULT 0,status ENUM('active','discontinued') NOT NULL DEFAULT 'active',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB;
INSERT INTO users(nama,username,password) VALUES('Administrator','admin','$2y$12$0o2FvcdZ9YWgc3HYnpF0POky4Dmr7fXJO/vxOg846SqsFsYGHFmJS');
INSERT INTO categories(nama_kategori) VALUES('Elektronik'),('Aksesoris'),('Periferal'),('Komponen Komputer'),('Jaringan');
INSERT INTO products(nama_produk,deskripsi,harga,stok,status) VALUES
('Laptop Lenovo IdeaPad','Laptop untuk kebutuhan kerja dan kuliah',7500000,8,'active'),
('Laptop ASUS VivoBook','Laptop serbaguna dengan desain ringkas',8200000,6,'active'),
('Laptop Acer Aspire 5','Laptop produktivitas harian',6900000,5,'active'),
('Laptop HP 14s','Laptop ringan untuk mobilitas',7100000,4,'discontinued'),
('MacBook Air M1','Laptop Apple untuk produktivitas',12500000,2,'active'),
('Samsung Galaxy A15','Smartphone Android',2300000,15,'active'),
('Xiaomi Redmi Note 13','Smartphone layar AMOLED',2800000,12,'active'),
('OPPO A78','Smartphone untuk penggunaan harian',3100000,7,'active'),
('Vivo Y27','Smartphone kamera jernih',2400000,9,'active'),
('iPhone 13','Smartphone Apple',9500000,3,'active'),
('Mouse Logitech M170','Mouse wireless',125000,25,'active'),
('Keyboard Mechanical','Keyboard mechanical RGB',450000,10,'active'),
('Headset JBL Tune','Headset audio',350000,14,'active'),
('Webcam Logitech C270','Webcam untuk meeting',420000,8,'active'),
('Mousepad Gaming','Mousepad ukuran besar',85000,30,'discontinued'),
('RAM DDR4 8GB','Memori desktop DDR4',280000,12,'active'),
('SSD Kingston 480GB','Penyimpanan SSD SATA',550000,9,'active'),
('Harddisk Seagate 1TB','Penyimpanan eksternal/internal',780000,6,'active'),
('Flashdisk Sandisk 64GB','Media penyimpanan USB',95000,22,'active'),
('VGA NVIDIA GTX 1650','Kartu grafis komputer',2400000,2,'active'),
('Router TP-Link','Router jaringan wireless',320000,11,'active'),
('Kabel LAN Cat6 10m','Kabel jaringan ethernet',65000,20,'active'),
('USB Hub 4 Port','Hub USB tambahan',110000,18,'active'),
('Charger USB-C 30W','Adaptor pengisian daya',175000,13,'active'),
('Speaker Bluetooth','Speaker portabel bluetooth',290000,7,'active');
