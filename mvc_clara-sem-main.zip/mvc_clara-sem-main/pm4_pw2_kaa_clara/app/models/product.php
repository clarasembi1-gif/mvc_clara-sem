<?php
class Product {
 private PDO $db; public function __construct(PDO $db){$this->db=$db;}
 public function all(string $search=''):array { $sql="SELECT * FROM products WHERE nama_produk LIKE :q OR deskripsi LIKE :q ORDER BY id DESC"; $s=$this->db->prepare($sql);$s->execute(['q'=>'%'.$search.'%']);return $s->fetchAll(); }
 public function find(int $id):?array {$s=$this->db->prepare('SELECT * FROM products WHERE id=?');$s->execute([$id]);return $s->fetch()?:null;}
 public function create(array $d):void {$s=$this->db->prepare('INSERT INTO products(nama_produk,deskripsi,harga,stok,status) VALUES(?,?,?,?,?)');$s->execute([$d['nama_produk'],$d['deskripsi'],$d['harga'],$d['stok'],$d['status']]);}
 public function update(int $id,array $d):void {$s=$this->db->prepare('UPDATE products SET nama_produk=?,deskripsi=?,harga=?,stok=?,status=? WHERE id=?');$s->execute([$d['nama_produk'],$d['deskripsi'],$d['harga'],$d['stok'],$d['status'],$id]);}
 public function delete(int $id):void {$s=$this->db->prepare('DELETE FROM products WHERE id=?');$s->execute([$id]);}
}
