<?php
class Dashboard {private PDO $db;public function __construct(PDO $db){$this->db=$db;}
 public function getSummary():array{return ['products'=>(int)$this->db->query('SELECT COUNT(*) FROM products')->fetchColumn(),'stock'=>(int)$this->db->query("SELECT COALESCE(SUM(stok),0) FROM products WHERE status='active'")->fetchColumn(),'users'=>(int)$this->db->query('SELECT COUNT(*) FROM users')->fetchColumn(),'categories'=>(int)$this->db->query('SELECT COUNT(*) FROM categories')->fetchColumn(),'discontinued'=>(int)$this->db->query("SELECT COUNT(*) FROM products WHERE status='discontinued'")->fetchColumn()];}
 public function getLatestProducts():array{return $this->db->query('SELECT * FROM products ORDER BY id DESC LIMIT 6')->fetchAll();}}
