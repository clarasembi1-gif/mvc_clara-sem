<?php
require_once __DIR__.'/../models/dashboard.php';
class HomeController {public function index(){global $pdo;requireLogin();$title='Dashboard';$m=new Dashboard($pdo);$summary=$m->getSummary();$latestProducts=$m->getLatestProducts();ob_start();require __DIR__.'/../../views/pages/home.php';$content=ob_get_clean();require __DIR__.'/../../views/layouts/main.php';}}
