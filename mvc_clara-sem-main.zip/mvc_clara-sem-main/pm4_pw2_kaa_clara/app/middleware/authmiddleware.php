<?php
function requireLogin(): void {
    if (empty($_SESSION['user_id'])) { header('Location: ' . BASE_URL . '/login'); exit; }
}
